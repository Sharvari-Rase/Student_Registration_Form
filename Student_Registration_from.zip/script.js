/* ============================================================
   STUDENT REGISTRATION FORM - script.js
   Beginner-friendly JavaScript demonstrating regular
   expressions, form validation, functions, event handling,
   and DOM manipulation. The page never reloads.
   ============================================================ */

/* ------------------------------------------------------------
   STEP 1: Grab references to all the HTML elements we need.
   ------------------------------------------------------------ */
const registrationForm = document.getElementById("registrationForm");

const fullNameInput = document.getElementById("fullName");
const emailInput = document.getElementById("email");
const mobileInput = document.getElementById("mobile");
const passwordInput = document.getElementById("password");
const confirmPasswordInput = document.getElementById("confirmPassword");
const cityInput = document.getElementById("city");

// Radio buttons come as a NodeList of all inputs named "gender"
const genderInputs = document.querySelectorAll('input[name="gender"]');
const genderGroup = document.querySelector(".radio-group");

const fullNameError = document.getElementById("fullNameError");
const emailError = document.getElementById("emailError");
const mobileError = document.getElementById("mobileError");
const passwordError = document.getElementById("passwordError");
const confirmPasswordError = document.getElementById("confirmPasswordError");
const genderError = document.getElementById("genderError");
const cityError = document.getElementById("cityError");

const resetBtn = document.getElementById("resetBtn");
const registerAnotherBtn = document.getElementById("registerAnotherBtn");

const formCard = document.getElementById("formCard");
const successCard = document.getElementById("successCard");
const detailsTableBody = document.getElementById("detailsTableBody");

/* ------------------------------------------------------------
   STEP 2: Regular expressions used for validation.
   Keeping them as named constants makes the rules easy to
   read and easy to reuse inside the validation functions.
   ------------------------------------------------------------ */

// Only alphabets and spaces allowed (supports multi-word names)
const NAME_REGEX = /^[A-Za-z ]+$/;

// A standard, practical email pattern: text@text.text
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Exactly 10 digits, nothing else
const MOBILE_REGEX = /^[0-9]{10}$/;

// At least 8 characters, no other restriction (kept simple for
// beginners - could be extended to require symbols/numbers etc.)
const PASSWORD_REGEX = /^.{8,}$/;

/* ------------------------------------------------------------
   FUNCTION: showError
   Small helper that displays an error message under a field
   and marks the field itself with the red "input-error" style.
   ------------------------------------------------------------ */
function showError(inputElement, errorElement, message) {
  errorElement.textContent = message;
  inputElement.classList.add("input-error");
}

/* ------------------------------------------------------------
   FUNCTION: clearAllErrors
   Resets every error message and every red field highlight.
   Called at the start of each validation attempt.
   ------------------------------------------------------------ */
function clearAllErrors() {
  const allErrorMessages = document.querySelectorAll(".error-msg");
  allErrorMessages.forEach(function (el) {
    el.textContent = "";
  });

  const allInputs = document.querySelectorAll(".input-error");
  allInputs.forEach(function (el) {
    el.classList.remove("input-error");
  });

  genderGroup.classList.remove("input-error");
}

/* ------------------------------------------------------------
   VALIDATION FUNCTIONS
   Each function checks ONE field and returns true/false.
   Keeping them separate (as required) makes each rule easy
   to read, test, and reuse.
   ------------------------------------------------------------ */

// Rule: Full Name must not be empty and must match NAME_REGEX
function validateFullName(value) {
  if (value === "") {
    showError(fullNameInput, fullNameError, "Full name is required.");
    return false;
  }
  if (!NAME_REGEX.test(value)) {
    showError(fullNameInput, fullNameError, "Only alphabets and spaces are allowed.");
    return false;
  }
  return true;
}

// Rule: Email must not be empty and must match EMAIL_REGEX
function validateEmail(value) {
  if (value === "") {
    showError(emailInput, emailError, "Email address is required.");
    return false;
  }
  if (!EMAIL_REGEX.test(value)) {
    showError(emailInput, emailError, "Enter a valid email address.");
    return false;
  }
  return true;
}

// Rule: Mobile number must not be empty and must be exactly 10 digits
function validateMobile(value) {
  if (value === "") {
    showError(mobileInput, mobileError, "Mobile number is required.");
    return false;
  }
  if (!MOBILE_REGEX.test(value)) {
    showError(mobileInput, mobileError, "Mobile number must contain exactly 10 digits.");
    return false;
  }
  return true;
}

// Rule: Password must not be empty and must be at least 8 characters
function validatePassword(value) {
  if (value === "") {
    showError(passwordInput, passwordError, "Password is required.");
    return false;
  }
  if (!PASSWORD_REGEX.test(value)) {
    showError(passwordInput, passwordError, "Password must be at least 8 characters long.");
    return false;
  }
  return true;
}

// Rule: Confirm Password must not be empty and must match Password
function validateConfirmPassword(password, confirmPassword) {
  if (confirmPassword === "") {
    showError(confirmPasswordInput, confirmPasswordError, "Please confirm your password.");
    return false;
  }
  if (confirmPassword !== password) {
    showError(confirmPasswordInput, confirmPasswordError, "Passwords do not match.");
    return false;
  }
  return true;
}

// Rule: One gender radio button must be selected
function validateGender(selectedGender) {
  if (!selectedGender) {
    genderError.textContent = "Please select a gender.";
    genderGroup.classList.add("input-error");
    return false;
  }
  return true;
}

// Rule: A city must be chosen from the dropdown
function validateCity(value) {
  if (value === "") {
    showError(cityInput, cityError, "Please select your city.");
    return false;
  }
  return true;
}

/* ------------------------------------------------------------
   FUNCTION: getSelectedGender
   Loops through the gender radio buttons and returns the value
   of whichever one is checked, or an empty string if none is.
   ------------------------------------------------------------ */
function getSelectedGender() {
  for (let i = 0; i < genderInputs.length; i++) {
    if (genderInputs[i].checked) {
      return genderInputs[i].value;
    }
  }
  return "";
}

/* ------------------------------------------------------------
   FUNCTION: buildDetailRow
   Small helper that creates one <tr> with a label cell and a
   value cell, used to build the final details table.
   ------------------------------------------------------------ */
function buildDetailRow(label, value) {
  const row = document.createElement("tr");

  const labelCell = document.createElement("td");
  labelCell.textContent = label;

  const valueCell = document.createElement("td");
  valueCell.textContent = value;

  row.appendChild(labelCell);
  row.appendChild(valueCell);

  return row;
}

/* ------------------------------------------------------------
   FUNCTION: showSuccess
   Builds the details table from the submitted data and swaps
   the form card out for the success card using DOM manipulation.
   Note: the password is intentionally NOT shown in the table,
   since real passwords should never be displayed on screen.
   ------------------------------------------------------------ */
function showSuccess(data) {
  // Clear any rows left over from a previous registration
  detailsTableBody.innerHTML = "";

  detailsTableBody.appendChild(buildDetailRow("Full Name", data.fullName));
  detailsTableBody.appendChild(buildDetailRow("Email", data.email));
  detailsTableBody.appendChild(buildDetailRow("Mobile Number", data.mobile));
  detailsTableBody.appendChild(buildDetailRow("Gender", data.gender));
  detailsTableBody.appendChild(buildDetailRow("City", data.city));

  formCard.hidden = true;
  successCard.hidden = false;
}

/* ------------------------------------------------------------
   FUNCTION: handleRegisterSubmit
   Runs when the form is submitted (Register button clicked).
   Validates every field, and only shows the success view if
   every single rule passes. event.preventDefault() stops the
   browser from reloading the page.
   ------------------------------------------------------------ */
function handleRegisterSubmit(event) {
  event.preventDefault(); // Stop the page from reloading

  clearAllErrors();

  // Read all current values from the form
  const fullName = fullNameInput.value.trim();
  const email = emailInput.value.trim();
  const mobile = mobileInput.value.trim();
  const password = passwordInput.value;
  const confirmPassword = confirmPasswordInput.value;
  const gender = getSelectedGender();
  const city = cityInput.value;

  // Run every validation function. Using "&" style separate
  // calls (not short-circuit &&) ensures ALL fields get checked
  // and ALL relevant error messages appear at once.
  const isNameValid = validateFullName(fullName);
  const isEmailValid = validateEmail(email);
  const isMobileValid = validateMobile(mobile);
  const isPasswordValid = validatePassword(password);
  const isConfirmPasswordValid = validateConfirmPassword(password, confirmPassword);
  const isGenderValid = validateGender(gender);
  const isCityValid = validateCity(city);

  const isFormValid =
    isNameValid &&
    isEmailValid &&
    isMobileValid &&
    isPasswordValid &&
    isConfirmPasswordValid &&
    isGenderValid &&
    isCityValid;

  // Stop here if anything failed - the error messages are
  // already visible on screen at this point.
  if (!isFormValid) {
    return;
  }

  // Everything passed - show the success card with the details
  showSuccess({
    fullName: fullName,
    email: email,
    mobile: mobile,
    gender: gender,
    city: city,
  });
}

/* ------------------------------------------------------------
   FUNCTION: handleResetClick
   Clears the entire form and any error messages, without
   touching the success card.
   ------------------------------------------------------------ */
function handleResetClick() {
  registrationForm.reset();
  clearAllErrors();
  fullNameInput.focus();
}

/* ------------------------------------------------------------
   FUNCTION: handleRegisterAnother
   Runs when the user clicks "Register Another Student" on the
   success card. Resets the form and switches back to it.
   ------------------------------------------------------------ */
function handleRegisterAnother() {
  registrationForm.reset();
  clearAllErrors();

  successCard.hidden = true;
  formCard.hidden = false;

  fullNameInput.focus();
}

/* ------------------------------------------------------------
   STEP 3: Wire up the event listeners.
   Using the form's "submit" event (rather than a plain button
   click) means pressing Enter inside any field also triggers
   validation correctly, and preventDefault() keeps the page
   from ever reloading.
   ------------------------------------------------------------ */
registrationForm.addEventListener("submit", handleRegisterSubmit);
resetBtn.addEventListener("click", handleResetClick);
registerAnotherBtn.addEventListener("click", handleRegisterAnother);
